package packetExamen;

public class Data {
	

	String dataTmp;
	
	public static boolean esData(String dataTmp) {
		if (dataTmp)) {
			return true;
		}
		else {
			return false;
		}
		
	}
}
