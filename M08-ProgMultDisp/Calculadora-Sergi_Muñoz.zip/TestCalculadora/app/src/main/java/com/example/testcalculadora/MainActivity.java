package com.example.testcalculadora;
//Sergi Muñoz Carmona, Dni: 39449342H
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private TextView textResult;
    private EditText num1;
    private EditText num2;
    private Button btAdd;
    private Button btSubs;
    private Button btMult;
    private Button btDiv;
    private Button btPow;
    private Button btCe;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Hooks = assignacions/enllaços
        textResult = (TextView) findViewById(R.id.textResult);
        num1 = (EditText) findViewById(R.id.num1);
        num2 = (EditText) findViewById(R.id.num2);
        btAdd = (Button) findViewById(R.id.btAdd);
        btSubs = (Button) findViewById(R.id.btSubs);
        btMult = (Button) findViewById(R.id.btMult);
        btDiv = (Button) findViewById(R.id.btDiv);
        btPow = (Button) findViewById(R.id.btPow);
        btCe = (Button) findViewById(R.id.btCe);

        textResult.setText("0.0");

        btAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //suma
                if (num1.getText().toString().trim().isEmpty() ||
                num2.getText().toString().trim().isEmpty()) {
                    Toast.makeText(MainActivity.this, "Enter a number", Toast.LENGTH_SHORT).show();

                }else {
                    double result = Double.parseDouble(num1.getText().toString().trim()) +
                            Double.parseDouble(num2.getText().toString().trim());
                    textResult.setText(result + "");
                }
            }
        });


        btSubs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //resta
                if (num1.getText().toString().trim().isEmpty() ||
                        num2.getText().toString().trim().isEmpty()) {
                    Toast.makeText(MainActivity.this, "Enter a number", Toast.LENGTH_SHORT).show();

                }else {
                    double result = Double.parseDouble(num1.getText().toString().trim()) -
                            Double.parseDouble(num2.getText().toString().trim());
                    textResult.setText(result + "");
                }
            }
        });

        btMult.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Mult
                if (num1.getText().toString().trim().isEmpty() ||
                        num2.getText().toString().trim().isEmpty()) {
                    Toast.makeText(MainActivity.this, "Enter a number", Toast.LENGTH_SHORT).show();

                }else {
                    double result = Double.parseDouble(num1.getText().toString().trim()) *
                            Double.parseDouble(num2.getText().toString().trim());
                    textResult.setText(result + "");
                }
            }
        });


        btDiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Div
                if (num1.getText().toString().trim().isEmpty() ||
                        num2.getText().toString().trim().isEmpty()) {
                    Toast.makeText(MainActivity.this, "Enter a number", Toast.LENGTH_SHORT).show();

                }else {
                    double result = Double.parseDouble(num1.getText().toString().trim()) /
                            Double.parseDouble(num2.getText().toString().trim());
                    textResult.setText(result + "");
                }
            }
        });

        btPow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Div
                if (num1.getText().toString().trim().isEmpty() ||
                        num2.getText().toString().trim().isEmpty()) {
                    Toast.makeText(MainActivity.this, "Enter a number", Toast.LENGTH_SHORT).show();

                }else {
                    double result = Math.pow(Double.parseDouble(num1.getText().toString().trim()),
                            Double.parseDouble(num2.getText().toString().trim()));
                    textResult.setText(result + "");
                }
            }
        });



        btCe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Borrar
                double result = 0.0;
                textResult.setText(result + "");
            }
        });
    }
}