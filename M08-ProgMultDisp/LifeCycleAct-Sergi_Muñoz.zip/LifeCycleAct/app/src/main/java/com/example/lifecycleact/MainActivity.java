package com.example.lifecycleact;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.util.Log;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    private static final String HOME_ACTIVITY_TAG = MainActivity.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toast.makeText(MainActivity.this, "onCreate method called", Toast.LENGTH_LONG).show();
        Log.d(HOME_ACTIVITY_TAG, "Activity created");

    }

    @Override
    protected void onStart() {
        super.onStart();
        Toast.makeText(MainActivity.this, "onStart method called", Toast.LENGTH_LONG).show();
        Log.d(HOME_ACTIVITY_TAG, "Activity started");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Toast.makeText(MainActivity.this, "onRestart method called", Toast.LENGTH_LONG).show();
        Log.d(HOME_ACTIVITY_TAG, "Activity Restarted");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Toast.makeText(MainActivity.this, "onResume method called", Toast.LENGTH_LONG).show();
        Log.d(HOME_ACTIVITY_TAG, "Activity Resumed");
    }


    @Override
    protected void onPause() {
        super.onPause();
        Toast.makeText(MainActivity.this, "onPause method called", Toast.LENGTH_LONG).show();
        Log.d(HOME_ACTIVITY_TAG, "Activity Paused");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Toast.makeText(MainActivity.this, "onStop method called", Toast.LENGTH_LONG).show();
        Log.d(HOME_ACTIVITY_TAG, "Activity Stopped");
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        Toast.makeText(MainActivity.this, "onDestroy method called", Toast.LENGTH_LONG).show();
        Log.d(HOME_ACTIVITY_TAG, "Activity is being Destroyed");
    }


}